#include <iostream>
using namespace std;

class Queue
{                           //Pehli ka back null hota
                           //Last ka next null hota

    private:
        int *Qarr,*temp;
        int *front,*back ;
        int size,len;
    
    public:
        Queue ()    //Constructor
        {
            front = back= NULL;
            cout <<"Enter the Size of array of Queue :  ";
            cin>> size;
            len=0;
            cout <<endl;
            Qarr =new int [size];
        }

        void enqueue()
        {
            if (front ==NULL)
            {
            front= back= temp = Qarr;
            cout <<"Enter value :   ";
            cin >> *front ;
            len++;
            cout <<endl;

            return;https://www.google.com/search?q=Write+a+C%2B%2B+program+to+convert+postfix+notation+to+Infix+notation.&ei=ec1eYpL9Jt2Xxc8P6v2imAw&ved=0ahUKEwjSnbWWsaD3AhXdS_EDHeq-CMMQ4dUDCA4&uact=5&oq=Write+a+C%2B%2B+program+to+convert+postfix+notation+to+Infix+notation.&gs_lcp=Cgdnd3Mtd2l6EAM6BwgAEEcQsANKBAhBGABKBAhGGABQvgZYvgZg8xdoAXABeACAAYgCiAGIApIBAzItMZgBAKABAqABAcgBCMABAQ&sclient=gws-wiz
            }len++;
            if (back+1== front)
               {
                cout <<"Queue is FULL!.."<<endl;
                return;
               }
            if (front == Qarr  && back==(Qarr + (size-1)))
            {
                cout <<"Queue is FULL!.."<<endl;
                return;
            }
            if (front != Qarr  && back==(Qarr + (size-1)))
            {
                back = Qarr;     
                cout <<"Enter the next value :  ";
                cin >>*back ;
                len++;
                //   *back =2;
                return;
            }
            back++;
            cout <<"Enter the next value :  ";
            cin >>*back ;len++;
            len++;
            cout <<endl;
            
            return;
        }

        void dequeue()
        {
            if (front == NULL)
            {
                cout <<"Queue is Empty!"<<endl;
                return ;
            }
            if (front == back )
            {
                front = back = NULL;
                cout<<"Queue is empty!"<<endl;
                return;
            }
            if (front == Qarr +(size-1))
            {
                front = Qarr;
                cout <<"Queue is empty!.."<<endl;
                return;
            }
            
            front ++;
            len--;
            return;
        }


        void print ()
        {
            if (front == NULL)
                {
                    cout <<"Queue is Empty."<<endl;
                    return;
                }

            temp=front;

            while (true)
            {
                cout <<*temp<<" ";
                if (temp == back)
                {
                    break;
                }
                if (temp == Qarr +(size-1))
                {
                    if (temp == back)
                    {
                        break;
                    }
                    temp = Qarr;
                }
                else
                {
                    temp ++;
                }
            }
            

        }

        bool isFUll()
        {
            if (len == size){
                return true;
            }
            else{
                return false;
            }
        }

        bool isEmpty()
        {
            if (front == NULL && back == NULL){
                return true;
            }
            else{
                return false;
            }
        }
};

int main ()
{
    Queue obj;
    obj.enqueue();
    obj.enqueue();
    obj.enqueue();
    obj.enqueue();
    obj.enqueue();
    
    
    
    cout<<endl;
    obj.print();
    
    cout<<endl;
    obj.dequeue();
    cout<<endl;
    obj.print();
    cout <<endl;
    return 0;
}