#include <algorithm>
#include <iterator>
#include <vector>
#include <string>
#include <iostream>
#include <sstream>

using namespace std;
class Stack 
{
    public:
        char *top;
        char *str;
        int size,len;
    
    
        Stack()    //Constructor
        {
            top = NULL;
            // cout <<"Enter the limit of stack :  ";
            // cin>> 
            size=100;
            len = 0;
            cout <<endl;
            str = new char[size];
            
        }

        void push(char x)
        {
            if (top == NULL)
            {
                top=str;
                *top = x;
                // *top=1;
                len ++;
                return;
            }
            

            if (str+(size-1) == top)
            {
                cout <<"Stack overflow";
                return ;
            }
            top++;
            *top = x;
            // *top=2;
            len ++;
            return;
        }

        void SwapStackString()
        {
            char *temp1;
            temp1 =str;

            for (int i = 0; i < len; i++)
            {
                cout <<*temp1 ;
                temp1++;
            }
            
        }

        void pop()
        {
            
            if (top == NULL)
            {
                cout <<"STACK UNDERFLOW"<<endl;
                return;
            }
            
            if (top == str)
            {
                top= NULL;
                return;
            }
            top--;
            len--;
            return;
        }

        char Top(){
            return *top;
        }

       void print ()
        {
        	char *temp;
        	temp = str;
            
            if (top== NULL)
            {
            	return;
                cout <<"UNDERFLOW!..."<<endl;
            }
           for (int i =0 ; i < len ; i++)
            {
                cout <<*temp<<"\t";
                temp++;
				
            }
        }

        


};

string ReverseString(string const& text)
{
    stringstream           inStream(text);
    stringstream           outStream;
    vector<string>    words;

    copy(istream_iterator<string>(inStream), istream_iterator<string>(), back_inserter(words));
    copy(words.rbegin(), words.rend(), ostream_iterator<string>(outStream, " "));
    return outStream.str();
}

void evalPostfix(string postfixExp, int len)
        {
            Stack S;
            string ch;
            S.size = len;
            int lenght=0;

            ch = ReverseString(postfixExp);

                for (int i = 0 ; i< len ; i++)
                {
                    if (ch [i] == 'A' ||  ch [i] == 'a') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'B' ||  ch [i] == 'b') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'C' ||  ch [i] == 'c') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'D' ||  ch [i] == 'd') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'E' ||  ch [i] == 'e') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'F' ||  ch [i] == 'f') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'G' ||  ch [i] == 'g') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'H' ||  ch [i] == 'h') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'I' ||  ch [i] == 'i') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'J' ||  ch [i] == 'j') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'K' ||  ch [i] == 'k') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'L' ||  ch [i] == 'l') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'M' ||  ch [i] == 'm') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'N' ||  ch [i] == 'n') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'O' ||  ch [i] == 'o') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'P' ||  ch [i] == 'p') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'Q' ||  ch [i] == 'q') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'R' ||  ch [i] == 'r') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'S' ||  ch [i] == 's') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'T' ||  ch [i] == 't') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'U' ||  ch [i] == 'u') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'V' ||  ch [i] == 'v') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'W' ||  ch [i] == 'w') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'X' ||  ch [i] == 'x') {
                        cout <<  ch[i]<<endl;
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'Y' ||  ch [i] == 'y') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    else if ( ch [i] == 'Z' ||  ch [i] == 'z') {
                        S.push( ch [i]);
                        lenght++;
                    }
                    
                }

                cout<<"Expression After removing punctuation:   " ;
                S.SwapStackString();
            
                cout << endl;
            
        }

int main ()
{
    string  postfixExp = "Kindness is what defines . , humanity !!";
    cout <<"Given Expression:   "<<postfixExp<<endl;
    int len = postfixExp.length();
    
    evalPostfix(postfixExp , len);

    return 0;
}